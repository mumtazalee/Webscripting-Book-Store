const books = [
    { title: "The Great Gatsby", author: "F. Scott Fitzgerald", genre: "fiction", price: 10.99, language: "English", rating: 4.5, image: "image/thegreatgatsby.jpg" },
    { title: "Harry Potter", author: "J.K. Rowling", genre: "fantasy", price: 12.99, language: "English", rating: 4.8, image: "image/harrypotter.jpg" },
    { title: "Sherlock Holmes", author: "Arthur Conan Doyle", genre: "mystery", price: 8.99, language: "English", rating: 4.6, image: "image/sherlockholmes.jpeg" },
    { title: "Sapiens", author: "Yuval Noah Harari", genre: "non-fiction", price: 15.99, language: "English", rating: 4.9, image: "image/sapiens.jpg" },
    { title: "The Alchemist", author: "Paulo Coelho", genre: "fiction", price: 9.99, language: "English", rating: 4.7, image: "image/alchemist.jpg" },
    { title: "The Sword of Kaigen", author: "M.L. Wang", genre: "fantasy", price: 11.99, language: "English", rating: 4.9, image: "image/swordofkaigen.png.jpg" },
    { title: "The Da Vinci Code", author: "Dan Brown", genre: "mystery", price: 7.99, language: "English", rating: 4.4, image: "image/davincicode.jpg" },
    { title: "Educated", author: "Tara Westover", genre: "non-fiction", price: 14.99, language: "English", rating: 4.8, image: "image/educated.jpg" },
    { title: "1984", author: "George Orwell", genre: "fiction", price: 10.99, language: "English", rating: 4.6, image: "image/1984.jpg" },
    { title: "Lord of the Rings", author: "J.R.R. Tolkien", genre: "fantasy", price: 13.99, language: "English", rating: 4.9, image: "image/lordoftherings.jpg" },
    {title: "The Woman", author: "Kristin Hannah", genre: "fiction", price: 13.59, language: "English", rating: 4.6, image: "image/thewoman.jpg"},
    {title: "Holes", author: "Louis Sachar", genre: "fiction", price: 8.99, language: "English", rating: 4.5, image: "image/holes.jpg"},
    {title: "An Orphan's War", author: "Molly Green", genre: "fiction", price: 9.99, language: "English", rating: 4.7, image: "image/anorphan'swar.jpg"},
    {title: "The Prison Doctor", author: "Amanda Brown", genre: "non-fiction", price: 12.99, language: "English", rating: 4.8, image: "image/theprisondoctor.jpg"},
    {title: "The Trading Game", author: "Gary Stevenson", genre: "non-fiction", price: 14.99, language: "English", rating: 4.9, image: "image/tradinggame.jpg"},
    {title: "Nine Lives", author: "Aimen Dean", genre: "non-fiction", price: 15.99, language: "English", rating: 4.7, image: "image/ninelives.jpg"},
    {title: "politicsontheedge", author: "Rory Stewart", genre: "non-fiction", price: 13.99, language: "English", rating: 4.6, image: "image/politicsontheedge.jpg"},
    {title: "The Asylum", author: "Carol Minto", genre: "non-fiction", price: 11.99, language: "English", rating: 4.5, image: "image/theasylum.jpg"},
    {title: "Family Matters", author: "Rohan Mistry", genre: "fiction", price: 10.99, language: "English", rating: 4.4, image: "image/familymatters.jpg"},
    {title: "Wooing The Witch Queen", author: "Stephanie Burgis", genre: "fantasy", price: 12.99, language: "English", rating: 4.3, image: "image/wooingthewitchqueen.jpg"},
    {title: "The Simply Truth", author: "David Baldacci", genre: "mystery", price: 9.99, language: "English", rating: 4.2, image: "image/thesimpletruth.jpg"},
    {title: "James Bond", author: "John Pearson", genre: "mystery", price: 8.99, language: "English", rating: 4.1, image: "image/jamesbond.jpg"},
    {title: "James", author: "Percival Everett", genre: "fiction", price: 7.99, language: "English", rating: 4.0, image: "image/james.jpg"},
    {title: "The Shadow of the Gods", author: "John Gwynne", genre: "fantasy", price: 6.99, language: "English", rating: 3.9, image: "image/theshadowofthegods.jpg"},
    {title: "Malice", author: "John Gwynne", genre: "fantasy", price: 5.99, language: "English", rating: 3.8, image: "image/malice.jpg"},
    {title: "Empire of the Vampire", author: "Jay Kristoff", genre: "fantasy", price: 5.99, language: "English", rating: 4.7, image: "image/empireofthevampire.jpg"},

];

// Search Books
function searchBooks(event) {
    event.preventDefault();

    const genre = document.getElementById("genre").value.toLowerCase();
    const author = document.getElementById("author").value.toLowerCase();

    const maxPrice = parseFloat(document.getElementById("price").value) || Infinity;
    const language = document.getElementById("language").value.toLowerCase();

    const results = books.filter(book =>
        (genre === "" || book.genre.toLowerCase() === genre) &&
        (author === "" || book.author.toLowerCase().includes(author)) &&
        (book.price <= maxPrice) &&
        (language === "" || book.language.toLowerCase().includes(language))
    );

    const bestMatch = results.length > 0 ? results.reduce((best, book) => (book.rating > best.rating ? book : best)) : null;
    
    displayResults(results, bestMatch);
}

// Display Results
function displayResults(filteredBooks, bestMatch) {
    const resultsDiv = document.getElementById("results");
    resultsDiv.innerHTML = "";

    if (filteredBooks.length === 0) {
        resultsDiv.innerHTML = "<p>No books found.</p>";
        return;
    }

    filteredBooks.forEach(book => {
        const bookDiv = document.createElement("div");
        bookDiv.classList.add("book-card");
        bookDiv.innerHTML = `<img src="${book.image}" alt="${book.title}">
                             <strong>${book.title}</strong> by ${book.author} - £${book.price} <br> ⭐ ${book.rating}/5`;

        if (bestMatch && book.title === bestMatch.title) {
            bookDiv.classList.add("best-match");
            bookDiv.innerHTML += `<br><strong>🔥 Best Match!</strong>`;
        }

        const wishlistBtn = document.createElement("button");
        wishlistBtn.innerText =  "Add to Wishlist";
        wishlistBtn.onclick = () => addToWishlist(book);
        bookDiv.appendChild(wishlistBtn);

        resultsDiv.appendChild(bookDiv);
    });
}
// User Login System
function loginUser() {
    const username = document.getElementById('username').value.trim();
    if (username) {
      localStorage.setItem('user', username);
      window.location.href = 'index.html';
    } else {
      alert('Please enter your name.');
    }
  }

// Display User
function displayUser() {
    const user = localStorage.getItem("user");
    const welcomeMsg = document.getElementById("welcome-message");
    if (user) {
        welcomeMsg.innerHTML = `Welcome, <strong>${user}</strong>!`;
    } else {
        welcomeMsg.innerHTML = "";
    }
}

// Logout
function logout() {
    localStorage.removeItem("user");
    window.location.href = "login.html"; // Redirect to login page
}


// Add to Wishlist
function addToWishlist(book) {
    const wishlist = document.getElementById("wishlist");

    if ([...wishlist.children].some(item => item.innerText.includes(book.title))) {
        alert("This book is already in your wishlist!");
        return;
    }

    const listItem = document.createElement("li");
    listItem.innerText = `${book.title} by ${book.author}`;
    wishlist.appendChild(listItem);

    let wishlistData = JSON.parse(localStorage.getItem("wishlist")) || [];
    wishlistData.push(book);
    localStorage.setItem("wishlist", JSON.stringify(wishlistData));
}

// Load Wishlist
function loadWishlist() {
    const wishlist = document.getElementById("wishlist");
    wishlist.innerHTML = "";
    JSON.parse(localStorage.getItem("wishlist"))?.forEach(book => addToWishlist(book));
}

// Clear Wishlist
function clearWishlist() {
    localStorage.removeItem("wishlist");
    document.getElementById("wishlist").innerHTML = "";
}

// Event Listeners
window.onload = loadWishlist;
document.getElementById("search-form").addEventListener("submit", searchBooks);
document.getElementById("clear-wishlist").addEventListener("click", clearWishlist);
